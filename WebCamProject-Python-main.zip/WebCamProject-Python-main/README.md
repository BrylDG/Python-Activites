# WebCamProject-Python
A python project for IT-PYTHON that uses webcam and take a snapshot.
